import { z } from 'zod';

export const cameraConfigSchema = z.object({
  id: z.string(),
  name: z.string(),
  url: z.string().url(),
  username: z.string().optional(),
  password: z.string().optional(),
  type: z.enum(['rtsp', 'http']),
});

export type CameraConfig = z.infer<typeof cameraConfigSchema>;

export class CameraManager {
  private static instance: CameraManager;
  private cameras: Map<string, CameraConfig> = new Map();

  private constructor() {}

  static getInstance(): CameraManager {
    if (!CameraManager.instance) {
      CameraManager.instance = new CameraManager();
    }
    return CameraManager.instance;
  }

  addCamera(config: CameraConfig) {
    this.cameras.set(config.id, config);
  }

  removeCamera(id: string) {
    this.cameras.delete(id);
  }

  getCamera(id: string): CameraConfig | undefined {
    return this.cameras.get(id);
  }

  getAllCameras(): CameraConfig[] {
    return Array.from(this.cameras.values());
  }

  // Método para validar la conexión con una cámara
  async testConnection(config: CameraConfig): Promise<boolean> {
    try {
      const response = await fetch('/api/camera/test', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(config),
      });
      return response.ok;
    } catch (error) {
      console.error('Error testing camera connection:', error);
      return false;
    }
  }
}
