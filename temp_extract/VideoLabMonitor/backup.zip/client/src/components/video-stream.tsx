import { useEffect, useRef, useState } from "react";
import { Card } from "@/components/ui/card";
import { AlertCircle } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { Camera } from "@shared/schema";

interface VideoStreamProps {
  camera: Camera;
}

export default function VideoStream({ camera }: VideoStreamProps) {
  const wsRef = useRef<WebSocket | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { user } = useAuth();

  useEffect(() => {
    if (!user || !camera.isActive) return;

    const connectWebSocket = () => {
      try {
        const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
        const wsUrl = `${protocol}//${window.location.host}/ws/${camera.id}`;

        wsRef.current = new WebSocket(wsUrl);

        wsRef.current.onopen = () => {
          console.log("WebSocket connected for camera:", camera.id);
          setIsConnected(true);
          setError(null);
        };

        wsRef.current.onclose = () => {
          console.log("WebSocket disconnected for camera:", camera.id);
          setIsConnected(false);
          // Attempt to reconnect after 3 seconds
          setTimeout(connectWebSocket, 3000);
        };

        wsRef.current.onerror = (event) => {
          console.error("WebSocket error for camera:", camera.id, event);
          setError("Failed to connect to video stream");
        };

      } catch (err) {
        console.error("WebSocket connection error for camera:", camera.id, err);
        setError("Failed to establish video connection");
      }
    };

    connectWebSocket();

    return () => {
      if (wsRef.current) {
        wsRef.current.close();
      }
    };
  }, [user, camera]);

  return (
    <Card className="aspect-video relative overflow-hidden">
      {!isConnected && !error && (
        <div className="absolute inset-0 flex items-center justify-center bg-background/80">
          <p className="text-muted-foreground">Connecting to {camera.name}...</p>
        </div>
      )}

      {error && (
        <div className="absolute inset-0 flex items-center justify-center bg-background/80">
          <div className="flex items-center gap-2 text-destructive">
            <AlertCircle className="h-4 w-4" />
            <p>{error}</p>
          </div>
        </div>
      )}

      <video
        className="w-full h-full object-cover"
        autoPlay
        playsInline
        muted
        style={{ display: isConnected ? 'block' : 'none' }}
      />
    </Card>
  );
}