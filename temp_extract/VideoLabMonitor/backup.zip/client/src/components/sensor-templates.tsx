import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Loader2, Plus } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

// Plantillas predefinidas para diferentes tipos de sensores
const sensorTemplates = {
  temperature: {
    type: "temperature",
    config: {
      protocol: "zigbee",
      interval: 30,
      unit: "°C"
    }
  },
  humidity: {
    type: "humidity",
    config: {
      protocol: "zigbee",
      interval: 30,
      unit: "%"
    }
  },
  motion: {
    type: "motion",
    config: {
      protocol: "zigbee",
      interval: 1,
    }
  },
  presence: {
    type: "presence",
    config: {
      protocol: "zigbee",
      interval: 1,
    }
  }
};

type SensorConfig = {
  name: string;
  type: string;
  config: {
    protocol: string;
    address: string;
    interval: number;
    unit?: string;
  };
};

export default function SensorTemplates() {
  const [isLoading, setIsLoading] = useState(false);
  const [config, setConfig] = useState<SensorConfig>({
    name: "",
    type: "motion", // Default to motion for Sonoff SNZB-04
    config: {
      protocol: "zigbee",
      address: "",
      interval: 1, // Intervalo más corto para detección de movimiento
      unit: undefined
    }
  });
  const { toast } = useToast();

  const handleTemplateSelect = (type: string) => {
    const template = sensorTemplates[type as keyof typeof sensorTemplates];
    setConfig(prev => ({
      ...prev,
      type,
      config: {
        ...template.config,
        address: prev.config.address
      }
    }));
  };

  const handleAddSensor = async () => {
    try {
      setIsLoading(true);
      const response = await fetch('/api/sensors', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(config),
      });

      if (response.ok) {
        toast({
          title: "Sensor Added",
          description: "The sensor has been configured successfully",
        });
        // Limpiar el formulario
        setConfig({
          name: "",
          type: "motion",
          config: {
            protocol: "zigbee",
            address: "",
            interval: 1,
            unit: undefined
          }
        });
      } else {
        const data = await response.json();
        throw new Error(data.message || 'Failed to add sensor');
      }
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : 'Failed to add sensor',
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Add New Sensor</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="name">Sensor Name</Label>
          <Input
            id="name"
            placeholder="Living Room Motion Sensor"
            value={config.name}
            onChange={(e) => setConfig(prev => ({ ...prev, name: e.target.value }))}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="type">Sensor Type</Label>
          <Select 
            value={config.type} 
            onValueChange={handleTemplateSelect}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select sensor type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="motion">Motion (Sonoff SNZB-04)</SelectItem>
              <SelectItem value="temperature">Temperature</SelectItem>
              <SelectItem value="humidity">Humidity</SelectItem>
              <SelectItem value="presence">Presence</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="address">Device Address</Label>
          <Input
            id="address"
            placeholder="00:11:22:33:44:55"
            value={config.config.address}
            onChange={(e) => setConfig(prev => ({ 
              ...prev, 
              config: { ...prev.config, address: e.target.value }
            }))}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="interval">Update Interval (seconds)</Label>
          <Input
            id="interval"
            type="number"
            value={config.config.interval}
            onChange={(e) => setConfig(prev => ({ 
              ...prev, 
              config: { ...prev.config, interval: parseInt(e.target.value) }
            }))}
          />
        </div>

        <Button
          onClick={handleAddSensor}
          disabled={!config.name || !config.config.address || isLoading}
          className="w-full"
        >
          {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          Add Sensor
        </Button>
      </CardContent>
    </Card>
  );
}