import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Loader2, Plus } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Camera } from "@shared/schema";

type CameraConfig = {
  name: string;
  url: string;
  type: string;
  username?: string;
  password?: string;
};

export default function CameraConfig() {
  const [isLoading, setIsLoading] = useState(false);
  const [config, setConfig] = useState<CameraConfig>({
    name: "",
    url: "",
    type: "rtsp",
  });
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: cameras } = useQuery<Camera[]>({
    queryKey: ["/api/cameras"],
  });

  const addCameraMutation = useMutation({
    mutationFn: async (config: CameraConfig) => {
      const response = await fetch('/api/cameras', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(config),
      });
      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.message || 'Failed to add camera');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/cameras'] });
      toast({
        title: "Camera Added",
        description: "The camera has been configured successfully",
      });
      setConfig({
        name: "",
        url: "",
        type: "rtsp",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleTestConnection = async () => {
    try {
      setIsLoading(true);
      const response = await fetch('/api/camera/test', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(config),
      });

      if (response.ok) {
        toast({
          title: "Connection Successful",
          description: "Camera is accessible and working correctly",
        });
      } else {
        const data = await response.json();
        throw new Error(data.message || 'Failed to connect to camera');
      }
    } catch (error) {
      toast({
        title: "Connection Failed",
        description: error instanceof Error ? error.message : 'Failed to connect to camera',
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <h3 className="text-sm font-medium">Active Cameras</h3>
        <div className="space-y-2">
          {cameras?.map((camera) => (
            <div
              key={camera.id}
              className="p-2 border rounded flex justify-between items-center"
            >
              <div>
                <p className="font-medium">{camera.name}</p>
                <p className="text-sm text-muted-foreground">{camera.url}</p>
              </div>
              <div className={`h-2 w-2 rounded-full ${camera.isActive ? 'bg-green-500' : 'bg-gray-300'}`} />
            </div>
          ))}
          {!cameras?.length && (
            <p className="text-sm text-muted-foreground">No cameras configured</p>
          )}
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Add New Camera</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">Camera Name</Label>
            <Input
              id="name"
              placeholder="Living Room Camera"
              value={config.name}
              onChange={(e) => setConfig(prev => ({ ...prev, name: e.target.value }))}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="url">Camera URL</Label>
            <Input
              id="url"
              placeholder="rtsp://camera.local:554/stream"
              value={config.url}
              onChange={(e) => setConfig(prev => ({ ...prev, url: e.target.value }))}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="type">Camera Type</Label>
            <Input
              id="type"
              placeholder="rtsp"
              value={config.type}
              onChange={(e) => setConfig(prev => ({ ...prev, type: e.target.value }))}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="username">Username (Optional)</Label>
            <Input
              id="username"
              placeholder="username"
              value={config.username || ""}
              onChange={(e) => setConfig(prev => ({ ...prev, username: e.target.value }))}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="password">Password (Optional)</Label>
            <Input
              id="password"
              type="password"
              placeholder="••••••••"
              value={config.password || ""}
              onChange={(e) => setConfig(prev => ({ ...prev, password: e.target.value }))}
            />
          </div>

          <div className="flex gap-2">
            <Button
              onClick={handleTestConnection}
              disabled={!config.url || isLoading}
            >
              {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Test Connection
            </Button>
            <Button 
              variant="outline" 
              disabled={isLoading || !config.name || !config.url}
              onClick={() => addCameraMutation.mutate(config)}
            >
              <Plus className="mr-2 h-4 w-4" />
              Add Camera
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}