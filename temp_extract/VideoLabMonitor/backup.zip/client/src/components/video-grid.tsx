import { Grid } from "lucide-react";
import { useState } from "react";
import VideoStream from "./video-stream";
import { Camera } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";

export default function VideoGrid() {
  const [layout, setLayout] = useState<'2x2' | '3x3'>('2x2');

  const { data: cameras } = useQuery<Camera[]>({
    queryKey: ["/api/cameras"],
    refetchInterval: 5000,
  });

  const gridClass = layout === '2x2' 
    ? 'grid-cols-2' 
    : 'grid-cols-3';

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-semibold">Video Streams</h2>
        <Button
          variant="outline"
          size="sm"
          onClick={() => setLayout(layout === '2x2' ? '3x3' : '2x2')}
        >
          <Grid className="h-4 w-4 mr-2" />
          {layout === '2x2' ? '2x2' : '3x3'} Layout
        </Button>
      </div>

      <div className={`grid ${gridClass} gap-4`}>
        {cameras?.filter(camera => camera.isActive).map((camera) => (
          <VideoStream key={camera.id} camera={camera} />
        ))}
      </div>
    </div>
  );
}
