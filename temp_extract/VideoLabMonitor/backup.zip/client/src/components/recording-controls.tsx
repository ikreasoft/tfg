import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { CircleDot, Square, AlertCircle } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";

export default function RecordingControls() {
  const [isRecording, setIsRecording] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [currentRecordingId, setCurrentRecordingId] = useState<number | null>(null);
  const wsRef = useRef<WebSocket | null>(null);
  const { user } = useAuth();
  const { toast } = useToast();

  // Comprueba si hay grabaciones activas al cargar el componente
  useEffect(() => {
    const checkActiveRecordings = async () => {
      try {
        const response = await fetch('/api/recordings');
        if (response.ok) {
          const recordings = await response.json();
          const activeRecording = recordings.find((r: any) => r.isActive);
          if (activeRecording) {
            setIsRecording(true);
            setCurrentRecordingId(activeRecording.id);
            // Reconectar el WebSocket si hay una grabación activa
            connectWebSocket();
          }
        }
      } catch (error) {
        console.error('Error checking active recordings:', error);
      }
    };

    if (user) {
      checkActiveRecordings();
    }
  }, [user]);

  useEffect(() => {
    return () => {
      if (wsRef.current) {
        wsRef.current.close();
      }
    };
  }, []);

  const connectWebSocket = async () => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      return wsRef.current;
    }

    try {
      const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
      const ws = new WebSocket(`${protocol}//${window.location.host}/ws`);

      return new Promise<WebSocket>((resolve, reject) => {
        const timeout = setTimeout(() => {
          ws.close();
          reject(new Error("Connection timeout"));
        }, 5000);

        ws.onopen = () => {
          clearTimeout(timeout);
          console.log("WebSocket connected");
          wsRef.current = ws;
          setupWebSocketHandlers(ws);
          resolve(ws);
        };

        ws.onerror = () => {
          clearTimeout(timeout);
          reject(new Error("Failed to connect"));
        };
      });
    } catch (error) {
      console.error('WebSocket connection error:', error);
      throw error;
    }
  };

  const setupWebSocketHandlers = (ws: WebSocket) => {
    ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        console.log('WebSocket message received:', data);

        if (data.type === 'recording_started') {
          setIsRecording(true);
          setCurrentRecordingId(data.recordingId);
          queryClient.invalidateQueries({ queryKey: ['/api/recordings'] });
          toast({
            title: "Recording Started",
            description: "Your session is now being recorded"
          });
        } else if (data.type === 'recording_stopped') {
          setIsRecording(false);
          setCurrentRecordingId(null);
          queryClient.invalidateQueries({ queryKey: ['/api/recordings'] });
          toast({
            title: "Recording Stopped",
            description: "Your recording has been saved"
          });
          ws.close();
        } else if (data.type === 'error') {
          setError(data.message);
          toast({
            title: "Error",
            description: data.message,
            variant: "destructive"
          });
        }
      } catch (error) {
        console.error('Error processing WebSocket message:', error);
      }
    };

    ws.onclose = (event) => {
      console.log('WebSocket closed:', event);
      // Solo intentar reconectar si todavía estamos grabando y no fue un cierre intencional
      if (isRecording && event.code !== 1000) {
        console.log("WebSocket closed, attempting to reconnect...");
        setTimeout(async () => {
          try {
            await connectWebSocket();
          } catch (error) {
            console.error("Reconnection failed:", error);
            setError("Connection lost. Please try again.");
          }
        }, 3000);
      }
    };

    ws.onerror = (error) => {
      console.error('WebSocket error:', error);
      setError("WebSocket connection error");
    };
  };

  const handleStartRecording = async () => {
    if (!user) return;

    try {
      setIsConnecting(true);
      setError(null);
      const ws = await connectWebSocket();

      ws.send(JSON.stringify({
        type: 'start_recording',
        userId: user.id
      }));

    } catch (err) {
      console.error('Start recording error:', err);
      setError("Failed to start recording");
      toast({
        title: "Error",
        description: "Failed to start recording",
        variant: "destructive"
      });
    } finally {
      setIsConnecting(false);
    }
  };

  const handleStopRecording = async () => {
    if (!user || !wsRef.current || !currentRecordingId) return;

    try {
      wsRef.current.send(JSON.stringify({
        type: 'stop_recording',
        userId: user.id,
        recordingId: currentRecordingId
      }));
    } catch (err) {
      console.error('Stop recording error:', err);
      setError("Failed to stop recording");
      toast({
        title: "Error",
        description: "Failed to stop recording",
        variant: "destructive"
      });
    }
  };

  return (
    <Card className="p-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          {isRecording && (
            <div className="animate-pulse">
              <div className="h-3 w-3 rounded-full bg-red-500" />
            </div>
          )}
          {error && (
            <AlertCircle className="h-4 w-4 text-destructive" />
          )}
          <span className="font-medium">
            {error ? error : isRecording ? "Recording in progress..." : "Ready to record"}
          </span>
        </div>

        <div className="flex gap-2">
          {!isRecording ? (
            <Button 
              onClick={handleStartRecording}
              disabled={isConnecting}
            >
              <CircleDot className="h-4 w-4 mr-2" />
              {isConnecting ? "Connecting..." : "Start Recording"}
            </Button>
          ) : (
            <Button variant="destructive" onClick={handleStopRecording}>
              <Square className="h-4 w-4 mr-2" />
              Stop Recording
            </Button>
          )}
        </div>
      </div>
    </Card>
  );
}