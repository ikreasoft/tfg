import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Recording, Sensor } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Video, Clock, Activity, BarChart2, Radar } from "lucide-react";
import { format } from "date-fns";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

export default function HomePage() {
  const { user, logoutMutation } = useAuth();

  const { data: recordings } = useQuery<Recording[]>({
    queryKey: ["/api/recordings"],
  });

  const { data: sensors } = useQuery<Sensor[]>({
    queryKey: ["/api/sensors"],
    refetchInterval: 5000, // Actualizar cada 5 segundos
  });

  // Calculate statistics
  const totalRecordings = recordings?.length ?? 0;
  const activeRecordings = recordings?.filter(r => r.isActive).length ?? 0;
  const lastRecording = recordings?.[0];
  const activeSensors = sensors?.filter(s => s.isActive).length ?? 0;

  // Prepare chart data
  const recordingChartData = recordings?.map(recording => ({
    date: format(new Date(recording.startTime), 'MMM dd'),
    duration: recording.endTime ? 
      (new Date(recording.endTime).getTime() - new Date(recording.startTime).getTime()) / 1000 / 60 : 
      0
  })) ?? [];

  // Datos de actividad del sensor de movimiento (Sonoff SNZB-04)
  const motionSensor = sensors?.find(s => s.type === 'motion' && s.isActive);
  const motionEvents = motionSensor?.config?.events ?? [];
  const motionChartData = motionEvents.map(event => ({
    time: format(new Date(event.timestamp), 'HH:mm'),
    activity: event.detected ? 1 : 0,
  }));

  return (
    <div className="min-h-screen flex flex-col">
      <header className="border-b">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold">Living Lab Monitor</h1>
          <div className="flex items-center gap-4">
            <span>Welcome, {user?.username}</span>
            <Button variant="outline" onClick={() => logoutMutation.mutate()}>
              Logout
            </Button>
          </div>
        </div>
      </header>

      <main className="flex-1 container mx-auto px-4 py-8">
        <div className="grid gap-8">
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Recordings</CardTitle>
                <Video className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{totalRecordings}</div>
                <p className="text-xs text-muted-foreground">
                  Lifetime recordings
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Active Sessions</CardTitle>
                <Activity className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{activeRecordings}</div>
                <p className="text-xs text-muted-foreground">
                  Currently recording
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Last Recording</CardTitle>
                <Clock className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {lastRecording ? format(new Date(lastRecording.startTime), 'MMM dd') : 'N/A'}
                </div>
                <p className="text-xs text-muted-foreground">
                  {lastRecording?.isActive ? 'Currently Active' : 'Completed'}
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Active Sensors</CardTitle>
                <Radar className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{activeSensors}</div>
                <p className="text-xs text-muted-foreground">
                  Connected devices
                </p>
              </CardContent>
            </Card>
          </div>

          <div className="grid lg:grid-cols-2 gap-8">
            <Card className="col-span-1">
              <CardHeader>
                <CardTitle>Recording Duration</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[200px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={recordingChartData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis />
                      <Tooltip />
                      <Area 
                        type="monotone" 
                        dataKey="duration" 
                        stroke="hsl(var(--primary))" 
                        fill="hsl(var(--primary)/.2)" 
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card className="col-span-1">
              <CardHeader>
                <CardTitle>Motion Activity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[200px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={motionChartData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="time" />
                      <YAxis />
                      <Tooltip />
                      <Area 
                        type="step" 
                        dataKey="activity" 
                        stroke="hsl(var(--primary))" 
                        fill="hsl(var(--primary)/.2)" 
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="flex justify-center">
            <Button asChild size="lg">
              <Link href="/dashboard">Go to Dashboard</Link>
            </Button>
          </div>
        </div>
      </main>
    </div>
  );
}