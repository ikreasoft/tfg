import { useAuth } from "@/hooks/use-auth";
import VideoGrid from "@/components/video-grid";
import RecordingControls from "@/components/recording-controls";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Recording } from "@shared/schema";
import { format } from "date-fns";
import { Download, Settings, ChevronDown } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import CameraConfig from "@/components/camera-config";
import SensorTemplates from "@/components/sensor-templates";

export default function Dashboard() {
  const { user, logoutMutation } = useAuth();

  const { data: recordings, isLoading } = useQuery<Recording[]>({
    queryKey: ["/api/recordings"],
    refetchInterval: 5000,
  });

  const handleDownload = async (recordingId: number, filename: string) => {
    try {
      const response = await fetch(`/api/recordings/${recordingId}/download`);
      if (!response.ok) throw new Error('Download failed');

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } catch (error) {
      console.error('Error downloading recording:', error);
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <header className="border-b">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold">Dashboard</h1>
          <div className="flex items-center gap-4">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline">
                  Settings
                  <ChevronDown className="ml-2 h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                <Dialog>
                  <DialogTrigger asChild>
                    <DropdownMenuItem onSelect={(e) => e.preventDefault()}>
                      Configure Cameras
                    </DropdownMenuItem>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-[425px]">
                    <DialogHeader>
                      <DialogTitle>Camera Settings</DialogTitle>
                    </DialogHeader>
                    <CameraConfig />
                  </DialogContent>
                </Dialog>
                <Dialog>
                  <DialogTrigger asChild>
                    <DropdownMenuItem onSelect={(e) => e.preventDefault()}>
                      Add Sensors
                    </DropdownMenuItem>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-[425px]">
                    <DialogHeader>
                      <DialogTitle>Sensor Configuration</DialogTitle>
                    </DialogHeader>
                    <SensorTemplates />
                  </DialogContent>
                </Dialog>
              </DropdownMenuContent>
            </DropdownMenu>

            <Button variant="ghost" asChild>
              <Link href="/">Home</Link>
            </Button>
            <span>Welcome, {user?.username}</span>
            <Button variant="outline" onClick={() => logoutMutation.mutate()}>
              Logout
            </Button>
          </div>
        </div>
      </header>

      <main className="flex-1 container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-4">
            <VideoGrid />
            <RecordingControls />
          </div>

          <div className="space-y-4">
            <h2 className="text-xl font-semibold">Recent Recordings</h2>
            <div className="space-y-2">
              {isLoading ? (
                <p className="text-sm text-muted-foreground">Loading recordings...</p>
              ) : recordings && recordings.length > 0 ? (
                recordings.map((recording) => (
                  <div
                    key={recording.id}
                    className="p-4 border rounded-lg flex justify-between items-center bg-card hover:bg-accent/5 transition-colors"
                  >
                    <div>
                      <p className="font-medium">{recording.filename}</p>
                      <div className="text-sm text-muted-foreground space-y-1">
                        <p>Started: {format(new Date(recording.startTime), 'PPp')}</p>
                        {recording.endTime && (
                          <p>Ended: {format(new Date(recording.endTime), 'PPp')}</p>
                        )}
                        <p className="text-xs">
                          Status: {recording.isActive ? (
                            <span className="text-green-600">Active</span>
                          ) : (
                            <span className="text-blue-600">Completed</span>
                          )}
                        </p>
                      </div>
                    </div>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleDownload(recording.id, recording.filename)}
                      disabled={recording.isActive}
                    >
                      <Download className="h-4 w-4 mr-2" />
                      Download
                    </Button>
                  </div>
                ))
              ) : (
                <p className="text-sm text-muted-foreground">No recordings found</p>
              )}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}