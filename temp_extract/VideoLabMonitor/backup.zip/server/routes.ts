import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import fs from 'fs';
import path from 'path';
import fetch from 'node-fetch';

export function registerRoutes(app: Express): Server {
  setupAuth(app);

  const httpServer = createServer(app);
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  // Map to track camera WebSocket connections
  const cameraConnections = new Map<number, Set<WebSocket>>();

  // Handle video stream websocket connections
  wss.on('connection', (ws: WebSocket) => {
    console.log('New video stream client connected');
    let cameraId: number | undefined = undefined;

    ws.on('message', async (message: string) => {
      try {
        const data = JSON.parse(message);
        console.log('Received WebSocket message:', data);

        if (data.type === 'start_recording') {
          const recording = await storage.createRecording({
            userId: data.userId,
            startTime: new Date(),
            filename: `recording_${Date.now()}.mp4`,
            isActive: true,
            endTime: null
          });
          console.log('Recording started:', recording);
          ws.send(JSON.stringify({ type: 'recording_started', recordingId: recording.id }));
        }

        if (data.type === 'stop_recording') {
          console.log('Stopping recording:', data);
          const recording = await storage.updateRecording(data.recordingId, {
            endTime: new Date(),
            isActive: false
          });
          console.log('Recording stopped:', recording);
          ws.send(JSON.stringify({ type: 'recording_stopped', recordingId: recording.id }));
          ws.close();
        }

        if (data.type === 'subscribe_camera' && typeof data.cameraId === 'number') {
          cameraId = data.cameraId;
          if (!cameraConnections.has(cameraId)) {
            cameraConnections.set(cameraId, new Set());
          }
          cameraConnections.get(cameraId)?.add(ws);
          console.log(`Client subscribed to camera ${cameraId}`);
        }
      } catch (error) {
        console.error('Error processing WebSocket message:', error);
        ws.send(JSON.stringify({ 
          type: 'error', 
          message: 'Failed to process request' 
        }));
      }
    });

    ws.on('error', (error) => {
      console.error('WebSocket error:', error);
    });

    ws.on('close', () => {
      console.log('Client disconnected');
      if (cameraId !== undefined && cameraConnections.has(cameraId)) {
        const connections = cameraConnections.get(cameraId);
        if (connections) {
          connections.delete(ws);
          if (connections.size === 0) {
            cameraConnections.delete(cameraId);
          }
        }
      }
    });
  });

  // REST API endpoints
  app.get('/api/recordings', async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    try {
      const recordings = await storage.getRecordings(req.user!.id);
      res.json(recordings);
    } catch (error) {
      console.error('Error fetching recordings:', error);
      res.status(500).json({ message: 'Failed to fetch recordings' });
    }
  });

  // Endpoint para obtener todas las cámaras del usuario
  app.get('/api/cameras', async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    try {
      const cameras = await storage.getCameras(req.user!.id);
      res.json(cameras);
    } catch (error) {
      console.error('Error fetching cameras:', error);
      res.status(500).json({ message: 'Failed to fetch cameras' });
    }
  });

  // Endpoint para agregar una nueva cámara
  app.post('/api/cameras', async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    try {
      const camera = await storage.createCamera({
        ...req.body,
        userId: req.user!.id,
        isActive: true
      });
      res.json(camera);
    } catch (error) {
      console.error('Error creating camera:', error);
      res.status(500).json({ message: 'Failed to create camera' });
    }
  });

  // Endpoint para probar la conexión con una cámara
  app.post('/api/camera/test', async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    try {
      const { url, type, username, password } = req.body;

      const response = await fetch(url, {
        method: 'GET',
        headers: username && password ? {
          'Authorization': 'Basic ' + Buffer.from(`${username}:${password}`).toString('base64')
        } : undefined
      });

      if (response.ok) {
        res.json({ success: true });
      } else {
        res.status(400).json({ success: false, message: 'Failed to connect to camera' });
      }
    } catch (error) {
      console.error('Error testing camera:', error);
      res.status(500).json({ success: false, message: 'Failed to test camera connection' });
    }
  });

  // Endpoint para obtener todos los sensores del usuario
  app.get('/api/sensors', async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    try {
      const sensors = await storage.getSensors(req.user!.id);
      res.json(sensors);
    } catch (error) {
      console.error('Error fetching sensors:', error);
      res.status(500).json({ message: 'Failed to fetch sensors' });
    }
  });

  // Endpoint para obtener eventos de un sensor específico
  app.get('/api/sensors/:id/events', async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    try {
      const sensor = await storage.getSensor(parseInt(req.params.id));
      if (!sensor) {
        return res.status(404).json({ message: 'Sensor not found' });
      }
      if (sensor.userId !== req.user!.id) {
        return res.status(403).json({ message: 'Unauthorized' });
      }
      res.json(sensor.config?.events || []);
    } catch (error) {
      console.error('Error fetching sensor events:', error);
      res.status(500).json({ message: 'Failed to fetch sensor events' });
    }
  });

  // Endpoint para descargar grabaciones
  app.get('/api/recordings/:id/download', async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    try {
      const recording = await storage.getRecording(parseInt(req.params.id));

      if (!recording) {
        return res.status(404).json({ message: 'Recording not found' });
      }

      if (recording.userId !== req.user!.id) {
        return res.status(403).json({ message: 'Unauthorized' });
      }

      const filePath = path.join(process.cwd(), 'recordings', recording.filename);

      if (!fs.existsSync(filePath)) {
        return res.status(404).json({ message: 'Recording file not found' });
      }

      res.download(filePath);
    } catch (error) {
      console.error('Error downloading recording:', error);
      res.status(500).json({ message: 'Failed to download recording' });
    }
  });

  return httpServer;
}